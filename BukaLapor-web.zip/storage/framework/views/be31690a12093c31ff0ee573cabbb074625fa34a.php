<?php $__env->startSection('activeReportDetail'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
$no = 1;
?>
<div class="container">
    <div class="row">
        <div class="col-md-8 mt-3">
            <div class="row">
                <div class="col-md-12 mb-3">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title">
                                <?php echo e($report->title); ?>

                                <?php if($report->status == "Done"): ?>
                                <span class="badge badge-pill badge-success">Selesai</span>
                                <?php endif; ?>
                            </h4>
                            <p><?php echo e(\App\Model\Instance::where('id', $report->id_instance)->first()->name); ?></p>
                            <p class="mt-3 mb-4"><?php echo e($report->subtitle); ?></p>
                            <?php if($report->id_user == Auth::user()->id): ?>
                            <?php if($report->status != "Done"): ?>
                            <div class="float-right">
                                <a href="<?php echo e(route('doneReportUser', $report->id)); ?>" class="btn btn-success">Laporan
                                    Selesai</a>
                                <a href="<?php echo e(route('deleteReport', $report->id)); ?>" class="btn btn-danger">Hapus
                                    Laporan</a>
                            </div>
                            <?php endif; ?>
                            <?php endif; ?>
                            <?php if($files != null): ?>
                            <p><b>File Lampiran</b></p>
                            <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e($no); ?> . <a href="<?php echo e(url('/Upload/FileLampiran/'.$file->file)); ?>"
                                    target="_BLANK"><?php echo e($file->file); ?></a></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <ul class="nav nav-tabs m-3" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab"
                                    aria-controls="home" aria-selected="true">Tindak Lanjut</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="laporanku-tab" data-toggle="tab" href="#laporanku" role="tab"
                                    aria-controls="profile" aria-selected="false">Komentar</a>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="tab-home">
                                <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card bg-light mb-1 ml-4 mr-4">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-1">
                                                <img class="avatar user-thumb"
                                                    src="<?php echo e(url('assets/images/author/avatar.png')); ?>" alt="avatar">
                                            </div>
                                            <div class="col-md-11">
                                                <?php if(\App\User::where('id', $action->id_user)->first()->role ==
                                                "User"): ?>
                                                <p><b><?php echo e(\App\User::where('id', $action->id_user)->first()->username); ?></b>
                                                </p>
                                                <?php else: ?>
                                                <p><b><?php echo e(\App\Model\Instance::where('id_user', $action->id_user)->first()->name); ?></b>
                                                </p>
                                                <?php endif; ?>
                                                <?php if($action->id_user == Auth::user()->id): ?>
                                                <div class="float-right">
                                                    <a href="<?php echo e(route('deleteResponseUser', ['id' => $action->id, 'id_report' => $report->id])); ?>"
                                                        style="color:red">Hapus Tanggapan</a>
                                                </div>
                                                <?php endif; ?>

                                                <p><?php echo e($action->content); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <form action="<?php echo e(action('UserController@response_user')); ?>" method="POST"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="card bg-light mb-1 ml-4 mr-4">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-md-1">
                                                    <img class="avatar user-thumb"
                                                        src="<?php echo e(url('assets/images/author/avatar.png')); ?>" alt="avatar">
                                                </div>
                                                <div class="col-md-11">
                                                    <div class="form-group">
                                                        <input type="hidden" name="id_report" value="<?php echo e($report->id); ?>">
                                                        <textarea class="form-control" id="exampleFormControlTextarea1"
                                                            rows="3" name="message"
                                                            placeholder="Berikan Tanggapan/Tindak lanjut ....."
                                                            required></textarea>
                                                        <button type="submit"
                                                            class="btn btn-primary float-right mt-2">Kirim</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="tab-pane fade show" id="laporanku" role="tabpanel"
                                aria-labelledby="laporanku-tab">
                                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card bg-light mb-1 ml-4 mr-4">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-1">
                                                <img class="avatar user-thumb"
                                                    src="<?php echo e(url('assets/images/author/avatar.png')); ?>" alt="avatar">
                                            </div>
                                            <div class="col-md-11">
                                                <p><b><?php echo e(\App\User::where('id', $comment->id_user)->first()->username); ?></b>
                                                </p>
                                                <?php if($comment->id_user == Auth::user()->id): ?>
                                                <div class="float-right">
                                                    <a href="<?php echo e(route('deleteComment', ['id' => $comment->id, 'id_report' => $report->id])); ?>"
                                                        style="color:red">Hapus Komentar</a>
                                                </div>
                                                <?php endif; ?>
                                                <p><?php echo e($comment->content); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <form action="<?php echo e(action('UserController@addedReportComment')); ?>" method="POST"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="card bg-light mb-1 ml-4 mr-4">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-md-1">
                                                    <img class="avatar user-thumb"
                                                        src="<?php echo e(url('assets/images/author/avatar.png')); ?>" alt="avatar">
                                                </div>
                                                <div class="col-md-11">
                                                    <div class="form-group">
                                                        <input type="hidden" name="id_report" value="<?php echo e($report->id); ?>">
                                                        <textarea class="form-control" id="exampleFormControlTextarea1"
                                                            rows="3" name="comment" placeholder="Komentar Anda ...."
                                                            required></textarea>
                                                        <button type="submit"
                                                            class="btn btn-primary float-right mt-2">Kirim</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mt-3">
             <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, ['header' => 'BukaLapor']); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <p class="mb-3">Selamat datang diwebsite BukaLapor Lorem ipsum dolor sit amet consectetur,
                    adipisicing
                    elit.
                    Totam debitis vero error repellat deserunt dicta, doloribus dolore similique, magni commodi id
                    facilis
                    reiciendis, eius nostrum? Dolor culpa tenetur corrupti facere. Lorem, ipsum dolor sit amet
                    consectetur
                    adipisicing elit. Soluta harum ut sed fugiat labore, a eius aut velit dolore cumque doloremque
                    voluptatibus quaerat error ex delectus! Molestiae quidem excepturi natus totam rem voluptatum
                    soluta
                    aliquid cupiditate sunt nesciunt nihil debitis sint repellendus, unde cum quia, vel iure
                    blanditiis
                    eaque consequatur? Reiciendis molestiae repudiandae est magni neque? Ipsam qui praesentium,
                    mollitia
                    minima laboriosam dolore dolores quae rerum, nulla reprehenderit esse aspernatur excepturi
                    temporibus?
                    Reprehenderit illo eligendi aliquid distinctio quasi molestias itaque, facere earum culpa, quae
                    id
                    et
                    fugit ex sunt consequuntur laboriosam architecto. Veritatis temporibus fuga nulla nobis veniam,
                    pariatur
                    minima.</p>
             <?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.templateNavigationListUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.templateUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rizki Fadilla\Documents\GitHub\BukaLapor-web\resources\views\user\reportDetail.blade.php ENDPATH**/ ?>