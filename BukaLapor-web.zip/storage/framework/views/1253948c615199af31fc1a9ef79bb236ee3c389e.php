<?php $__env->startSection('activeAddInstance'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<div class="breadcrumbs-area clearfix">
    <h4 class="page-title pull-left">Detail Laporan</h4>
    <ul class="breadcrumbs pull-left">
        
        <li><a href="<?php echo e(route('indexReportVerification')); ?>"><span>Verifikasi</span></a></li>
        <li><span>Detail</span></li>
    </ul>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
$no = 1;
?>
<div class="row">
    <div class="col-md-12 mt-5">
        <div class="card">
            <div class="card-body">
                <h4 class="header-title"><?php echo e($report->title); ?></h4>
                <p><?php echo e(\App\User::where('id', $report->id_user)->first()->username); ?></p>
                <p class="mt-3 mb-4"><?php echo e($report->subtitle); ?></p>
                <?php if($files != null): ?>
                <p><b>File Lampiran</b></p>
                <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($no); ?> . <a href="<?php echo e(url('/Upload/FileLampiran/'.$file->file)); ?>"
                        target="_BLANK"><?php echo e($file->file); ?></a></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="float-right">
                    <button type="button" class="btn btn-danger" data-toggle="modal"
                        data-target="#exampleModalCenter">Tolak</button>
                    <a href="<?php echo e(route('accept',$report->id)); ?>" class="btn btn-success">Terima</a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Tambahkan Pesan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="post" action="<?php echo e(action('AdminController@reject')); ?>" enctype="multipart/form-data"
                class="ml-2">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <input type="hidden" name="id_report" value="<?php echo e($report->id); ?>">
                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="message"
                            required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-success float-right mt-3" type="submit">submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div id="tolakForm">

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.templateNavigationList', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rizki Fadilla\Documents\GitHub\BukaLapor-web\resources\views/admin/reportDetails.blade.php ENDPATH**/ ?>