<div class="card">
    <div class="card-body pb-0">
        <h4 class="header-title">{{ $header }}</h4>
        {{ $slot }}
    </div>
</div>
