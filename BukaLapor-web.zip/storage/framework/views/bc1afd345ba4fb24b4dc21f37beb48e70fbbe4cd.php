<div class="card">
    <div class="card-body pb-0">
        <h4 class="header-title"><?php echo e($header); ?></h4>
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH C:\Users\Rizki Fadilla\Documents\GitHub\BukaLapor-web\resources\views/components/card.blade.php ENDPATH**/ ?>