<?php $__env->startSection('activeReportData'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<div class="breadcrumbs-area clearfix">
    <h4 class="page-title pull-left">Detail Laporan</h4>
    <ul class="breadcrumbs pull-left">
        
        <li><a href="<?php echo e(route('indexReportVerification')); ?>"><span>Verifikasi</span></a></li>
        <li><span>Detail</span></li>
    </ul>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
$no = 1;
?>
<div class="row">
    <div class="col-md-12 mt-5">
        <div class="card">
            <div class="card-body">
                <h4 class="header-title"><?php echo e($report->title); ?></h4>
                <p><?php echo e(\App\User::where('id', $report->id_user)->first()->username); ?></p>
                <p class="mt-3 mb-4"><?php echo e($report->subtitle); ?></p>
                <?php if($files != null): ?>
                <p><b>File Lampiran</b></p>
                <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($no); ?> . <a href="<?php echo e(url('/Upload/FileLampiran/'.$file->file)); ?>"
                        target="_BLANK"><?php echo e($file->file); ?></a></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <ul class="nav nav-tabs m-3" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab"
                            aria-controls="home" aria-selected="true">Tindak Lanjut</a>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="tab-home">
                        <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card bg-light mb-1 ml-4 mr-4">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-1">
                                        <img class="avatar user-thumb"
                                            src="<?php echo e(url('assets/images/author/avatar.png')); ?>" alt="avatar">
                                    </div>
                                    <div class="col-md-11">
                                        <p><b><?php echo e(\App\Model\Instance::where('id_user', $action->id_user)->first()->name); ?></b></p>
                                        <div class="float-right">
                                            <a href="<?php echo e(route('deleteResponse', ['id' => $action->id, 'id_report' => $report->id])); ?>" style="color:red">Hapus</a>
                                        </div>
                                        <p><?php echo e($action->content); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <form action="<?php echo e(action('InstanceController@response')); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="card bg-light mb-1 ml-4 mr-4">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <img class="avatar user-thumb"
                                                src="<?php echo e(url('assets/images/author/avatar.png')); ?>" alt="avatar">
                                        </div>
                                        <div class="col-md-11">
                                            <div class="form-group">
                                                <input type="hidden" name="id_report" value="<?php echo e($report->id); ?>">
                                                <textarea class="form-control" id="exampleFormControlTextarea1"
                                                    rows="3" name="message" placeholder="Berikan Tanggapan/Tindak lanjut ....."
                                                    required></textarea>
                                                <button type="submit"
                                                    class="btn btn-primary float-right mt-2">Kirim</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.templateNavigationList', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rizki Fadilla\Documents\GitHub\BukaLapor-web\resources\views/instance/reportDetails.blade.php ENDPATH**/ ?>