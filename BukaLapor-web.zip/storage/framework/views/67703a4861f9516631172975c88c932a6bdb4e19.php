<?php $__env->startSection('activeHome'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 mt-3">
             <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, ['header' => 'Laporkan']); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <div class="row">
                    <div class="col-md-12">
                        <form action="<?php echo e(action('UserController@addedReportData')); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="example-text-input" class="col-form-label">Judul Laporan</label>
                                <input class="form-control" type="text" id="example-text-input" name="title" required>
                                <label for="exampleFormControlTextarea1" class="mt-2">Detail Laporan</label>
                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="subtitle"
                                    required></textarea>
                                <label class="col-form-label mt-2">Kategori</label>
                                <select class="custom-select select2" id="provinsiSelect" name="seen" required>
                                    <option selected="selected" disabled>Pilih Kategori</option>
                                    <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label for="example-text-input" class="col-form-label mt-2">Lampiran ( jika tidak
                                    ada
                                    kosongkan )</label>
                                <div class="input-group mb-3">
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" id="inputGroupFile01"
                                            name="lampiran">
                                        <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                    </div>
                                </div>
                                <input type="submit" class="btn btn-rounded btn-success mb-3 mt-3 float-right"
                                    value="Simpan">
                            </div>
                        </form>
                    </div>
                </div>
             <?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        </div>
        <div class="col-md-4 mt-3">
             <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, ['header' => 'BukaLapor']); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <p class="mb-3">Selamat datang diwebsite BukaLapor Lorem ipsum dolor sit amet consectetur,
                    adipisicing
                    elit.
                    Totam debitis vero error repellat deserunt dicta, doloribus dolore similique, magni commodi id
                    facilis
                    reiciendis, eius nostrum? Dolor culpa tenetur corrupti facere. Lorem, ipsum dolor sit amet
                    consectetur
                    adipisicing elit. Soluta harum ut sed fugiat labore, a eius aut velit dolore cumque doloremque
                    voluptatibus quaerat error ex delectus! Molestiae quidem excepturi natus totam rem voluptatum
                    soluta
                    aliquid cupiditate sunt nesciunt nihil debitis sint repellendus, unde cum quia, vel iure
                    blanditiis
                    eaque consequatur? Reiciendis molestiae repudiandae est magni neque? Ipsam qui praesentium,
                    mollitia
                    minima laboriosam dolore dolores quae rerum, nulla reprehenderit esse aspernatur excepturi
                    temporibus?
                    Reprehenderit illo eligendi aliquid distinctio quasi molestias itaque, facere earum culpa, quae
                    id
                    et
                    fugit ex sunt consequuntur laboriosam architecto. Veritatis temporibus fuga nulla nobis veniam,
                    pariatur
                    minima.</p>
             <?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.templateNavigationListUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.templateUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rizki Fadilla\Documents\GitHub\BukaLapor-web\resources\views\user\homeUser.blade.php ENDPATH**/ ?>