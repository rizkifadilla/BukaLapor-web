<?php $__env->startSection('templateNavigationListUser'); ?>

<li class="<?php echo $__env->yieldContent('activeLaporan'); ?>"><a href="<?php echo e(route('indexMyReport')); ?>"><i class="far fa-file-alt"></i> <span>Laporan</span></li>
<li class="<?php echo $__env->yieldContent('activeTentang'); ?>"><a href="#"><i class="ti-map-alt"></i> <span>Tentang BukaLapor</span></a></li>

<?php $__env->stopSection(); ?><?php /**PATH C:\Users\Rizki Fadilla\Documents\GitHub\BukaLapor-web\resources\views/layouts/templateNavigationListUser.blade.php ENDPATH**/ ?>