<?php $__env->startSection('activeMyReport'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 mt-3">
             <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, ['header' => '']); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <div class="row">
                    <div class="col-md-12 mb-3">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab"
                                    aria-controls="home" aria-selected="true">Semua</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="laporanku-tab" data-toggle="tab" href="#laporanku" role="tab"
                                    aria-controls="profile" aria-selected="false">LaporanKu</a>
                            </li>
                            
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="tab-home">
                                <?php $__currentLoopData = $allReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allReport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="card">
                                    <div class="card-body">
                                        <a href="<?php echo e(route('indexReportDetailUser', $allReport->id)); ?>">
                                            <div class="row">
                                                <div class="col-md-1">
                                                    <img class="avatar user-thumb"
                                                        src="<?php echo e(url('assets/images/author/avatar.png')); ?>" alt="avatar">
                                                </div>
                                                <div class="col-md-11">
                                                    <p><b><?php echo e(\App\User::where('id', $allReport->id_user)->first()->username); ?></b>
                                                    </p>
                                                    <p><?php echo e(\App\Model\Instance::where('id', $allReport->id_instance)->first()->name); ?>

                                                    </p>
                                                    <p class="mt-2 mb-1"><b><?php echo e($allReport->title); ?></b></p>
                                                    <p><?php echo e($allReport->subtitle); ?></p>
                                                </div>
                                            </div>
                                        </a>
                                        <div class="col-md-1"></div>
                                        <div class="col-md-11">
                                            <div class="horizontal-menu mt-3">
                                                <nav>
                                                    <ul id="nav_menu">
                                                        <li><i class="far fa-building"></i><span class="mr-3">Tindak
                                                                Lanjut
                                                                <?php echo e(\App\Model\ReportAction::where('id_report', $allReport->id)->count()); ?></span>
                                                        </li>
                                                        <li><i class="far fa-comments"></i> <span>Komentar
                                                                <?php echo e(\App\Model\ReportComment::where('id_report', $allReport->id)->count()); ?></span>
                                                        </li>
                                                        <li>
                                                            <div id="supporthtml<?php echo e($allReport->id); ?>">
                                                                <a href="javascript:void();" class="support"
                                                                    data-id="<?php echo e($allReport->id); ?>">

                                                                    <?php if(\App\Model\ReportSupport::where('id_user',
                                                                    Auth::user()->id)->where('id_report',
                                                                    $allReport->id)->first() == null): ?>
                                                                    <i class="far fa-thumbs-up"></i>
                                                                    <?php else: ?>
                                                                    <i class="fas fa-thumbs-up"></i>
                                                                    <?php endif; ?>

                                                                    <span>Dukung
                                                                        <?php echo e(\App\Model\ReportSupport::where('id_report', $allReport->id)->count()); ?></span>
                                                                </a>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </nav>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="tab-pane fade show" id="laporanku" role="tabpanel"
                                aria-labelledby="laporanku-tab">
                                <?php $__currentLoopData = $myReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myReport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('indexReportDetailUser', $myReport->id)); ?>">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-md-1">
                                                    <img class="avatar user-thumb"
                                                        src="<?php echo e(url('assets/images/author/avatar.png')); ?>" alt="avatar">
                                                </div>
                                                <div class="col-md-11">
                                                    <p><b><?php echo e(\App\User::where('id', $myReport->id_user)->first()->username); ?></b>
                                                    </p>
                                                    <p><?php echo e(\App\Model\Instance::where('id', $myReport->id_instance)->first()->name); ?>

                                                    </p>
                                                    <p class="mt-2 mb-1"><b><?php echo e($myReport->title); ?></b></p>
                                                    <p><?php echo e($myReport->subtitle); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            </a>
                            
                        </div>
                    </div>
                </div>
             <?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        </div>
        <div class="col-md-4 mt-3">
             <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, ['header' => 'BukaLapor']); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <p class="mb-3">Selamat datang diwebsite BukaLapor Lorem ipsum dolor sit amet consectetur,
                    adipisicing
                    elit.
                    Totam debitis vero error repellat deserunt dicta, doloribus dolore similique, magni commodi id
                    facilis
                    reiciendis, eius nostrum? Dolor culpa tenetur corrupti facere. Lorem, ipsum dolor sit amet
                    consectetur
                    adipisicing elit. Soluta harum ut sed fugiat labore, a eius aut velit dolore cumque doloremque
                    voluptatibus quaerat error ex delectus! Molestiae quidem excepturi natus totam rem voluptatum
                    soluta
                    aliquid cupiditate sunt nesciunt nihil debitis sint repellendus, unde cum quia, vel iure
                    blanditiis
                    eaque consequatur? Reiciendis molestiae repudiandae est magni neque? Ipsam qui praesentium,
                    mollitia
                    minima laboriosam dolore dolores quae rerum, nulla reprehenderit esse aspernatur excepturi
                    temporibus?
                    Reprehenderit illo eligendi aliquid distinctio quasi molestias itaque, facere earum culpa, quae
                    id
                    et
                    fugit ex sunt consequuntur laboriosam architecto. Veritatis temporibus fuga nulla nobis veniam,
                    pariatur
                    minima.</p>
             <?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $('.support').on('click', function (e) {
            e.preventDefault();
            var id = $(this).data('id');
            console.log(id);
            $.ajax({
                url: "<?php echo e(url('user/support' )); ?>" + '/' + id,
                type: "GET",
                dataType: "json",

                success: function (data) {
                    $('#supporthtml' + id).html(
                        '<a href="javascript:void();" class="support" data-id="<?php echo e($allReport->id); ?>">  <i class="fas fa-thumbs-up"></i> <span>Dukung '+data+'</span> </a>'
                    )
                },
                error: function (data) {
                    console.log(data);
                },
            });

        })
    })

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.templateNavigationListUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.templateUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rizki Fadilla\Documents\GitHub\BukaLapor-web\resources\views\user\myReport.blade.php ENDPATH**/ ?>