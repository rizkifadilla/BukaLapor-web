<?php $__env->startSection('activeHome'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<div class="breadcrumbs-area clearfix">
    <h4 class="page-title pull-left">Home</h4>
    <ul class="breadcrumbs pull-left">
        
        <li><span>Home</span></li>
    </ul>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 mt-5">
         <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, ['header' => 'BukaLapor']); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <p class="mb-3">Selamat datang diwebsite BukaLapor Lorem ipsum dolor sit amet consectetur, adipisicing elit.
                Totam debitis vero error repellat deserunt dicta, doloribus dolore similique, magni commodi id facilis
                reiciendis, eius nostrum? Dolor culpa tenetur corrupti facere. Lorem, ipsum dolor sit amet consectetur
                adipisicing elit. Soluta harum ut sed fugiat labore, a eius aut velit dolore cumque doloremque
                voluptatibus quaerat error ex delectus! Molestiae quidem excepturi natus totam rem voluptatum soluta
                aliquid cupiditate sunt nesciunt nihil debitis sint repellendus, unde cum quia, vel iure blanditiis
                eaque consequatur? Reiciendis molestiae repudiandae est magni neque? Ipsam qui praesentium, mollitia
                minima laboriosam dolore dolores quae rerum, nulla reprehenderit esse aspernatur excepturi temporibus?
                Reprehenderit illo eligendi aliquid distinctio quasi molestias itaque, facere earum culpa, quae id et
                fugit ex sunt consequuntur laboriosam architecto. Veritatis temporibus fuga nulla nobis veniam, pariatur
                minima.</p>
         <?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.templateNavigationList', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rizki Fadilla\Documents\GitHub\BukaLapor-web\resources\views/home.blade.php ENDPATH**/ ?>