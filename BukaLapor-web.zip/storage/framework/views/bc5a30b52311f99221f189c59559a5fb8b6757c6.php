<?php $__env->startSection('activeAddInstance'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<div class="breadcrumbs-area clearfix">
    <h4 class="page-title pull-left">Tambah Instansi</h4>
    <ul class="breadcrumbs pull-left">
        
        <li><span>Tambah</span></li>
    </ul>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 mt-5">
         <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, ['header' => 'Form Tambah Instansi']); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <div class="row">
                <div class="col-md-12">
                <form action="<?php echo e(action('AdminController@addedInstance')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="example-text-input" class="col-form-label">Username</label>
                            <input class="form-control" type="text" id="example-text-input" name="username">
                            <label for="example-text-input" class="col-form-label">email</label>
                            <input class="form-control" type="email" id="example-text-input" name="email">
                            <label for="example-text-input" class="col-form-label">password</label>
                            <input class="form-control" type="text" id="example-text-input" name="password">
                            <input type="submit" class="btn btn-rounded btn-success mb-3 mt-3 float-right" value="Simpan">
                        </div>
                    </form>
                </div>
            </div>
         <?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.templateNavigationList', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rizki Fadilla\Documents\GitHub\BukaLapor-web\resources\views\admin\addedInstance.blade.php ENDPATH**/ ?>