
<?php $__env->startSection('templateNavigationList'); ?>
    <li class="<?php echo $__env->yieldContent('activeHome'); ?>"><a href="home"><i class="fas fa-home"></i> <span>Home</span></a></li>

    <?php if( Auth::user()->role == 'Admin' ): ?>
        <li class="<?php echo $__env->yieldContent('activeAddInstance'); ?>"><a href="<?php echo e(route('indexAddedInstance')); ?>"><i class="fas fa-user-plus"></i> <span>Tambah Instansi</span></a></li>
        <li class="<?php echo $__env->yieldContent('activeReportVerification'); ?>"><a href="<?php echo e(route('indexReportVerification')); ?>"><i class="far fa-check-square"></i> <span>Verifikasi Laporan</span></a></li>

    <?php elseif( Auth::user()->role == 'Instance' ): ?>
        <li class="<?php echo $__env->yieldContent('activeIntanceData'); ?>"><a href="<?php echo e(route('indexInstanceData')); ?>"><i class="far fa-building"></i> <span>Data Instansi</span></a></li>
        <li class="<?php echo $__env->yieldContent('activeReportData'); ?>"><a href="<?php echo e(route('indexReportData')); ?>"><i class="far fa-file-alt"></i> <span>Laporan</span></a></li>

    

    <?php endif; ?>
<?php $__env->stopSection(); ?><?php /**PATH C:\Users\Rizki Fadilla\Documents\GitHub\BukaLapor-web\resources\views/layouts/templateNavigationList.blade.php ENDPATH**/ ?>